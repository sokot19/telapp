package com.example.telegramfilemanager.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.telegramfilemanager.model.FileItem
import com.example.telegramfilemanager.model.FileType

@Composable
fun FileViewer(fileItem: FileItem, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Box(modifier = Modifier.fillMaxSize()) {
            when (fileItem.fileType) {
                FileType.IMAGE -> ImageViewer(fileItem)
                FileType.VIDEO, FileType.AUDIO, FileType.VOICE -> MediaPlayer(fileItem)
                else -> {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Text("نمایش این نوع فایل در داخل برنامه پشتیبانی نمی‌شود.")
                    }
                }
            }
            IconButton(onClick = onDismiss, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
                Icon(Icons.Default.Close, "بستن", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ImageViewer(fileItem: FileItem) {
    AsyncImage(
        model = fileItem.path,
        contentDescription = fileItem.name,
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun MediaPlayer(fileItem: FileItem) {
    val context = LocalContext.current
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri("file://${fileItem.path}"))
            prepare()
            playWhenReady = true
        }
    }
    var showSpeedDialog by remember { mutableStateOf(false) }

    if (showSpeedDialog) {
        SpeedSelectionDialog(
            onDismiss = { showSpeedDialog = false },
            onSpeedSelected = { speed ->
                exoPlayer.setPlaybackSpeed(speed)
                showSpeedDialog = false
            }
        )
    }

    DisposableEffect(Unit) { onDispose { exoPlayer.release() } }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            factory = { PlayerView(it).apply { player = exoPlayer } },
            modifier = Modifier.fillMaxSize()
        )
        IconButton(
            onClick = { showSpeedDialog = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) {
            Icon(Icons.Default.Speed, "تغییر سرعت", tint = Color.White)
        }
    }
}

@Composable
private fun SpeedSelectionDialog(onDismiss: () -> Unit, onSpeedSelected: (Float) -> Unit) {
    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("انتخاب سرعت پخش") },
        text = {
            Column {
                speeds.forEach { speed ->
                    Text(
                        text = "${speed}x",
                        modifier = Modifier.fillMaxWidth().clickable { onSpeedSelected(speed) }.padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("بستن") } }
    )
}
