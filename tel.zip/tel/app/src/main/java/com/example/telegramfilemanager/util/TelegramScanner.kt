package com.example.telegramfilemanager.util

import com.example.telegramfilemanager.model.FileItem
import com.example.telegramfilemanager.model.FileType
import com.example.telegramfilemanager.model.toItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object TelegramScanner {
    private val publicDirs = listOf(
        "Telegram/Telegram Audio",
        "Telegram/Telegram Documents",
        "Telegram/Telegram Images",
        "Telegram/Telegram Video",
        "Telegram/Telegram Voice", // پوشه پیام‌های صوتی اضافه شد
        "Download/Telegram"
    )

    suspend fun scanPublicFolders(): Map<FileType, List<FileItem>> = withContext(Dispatchers.IO) {
        val baseDir = android.os.Environment.getExternalStorageDirectory().absolutePath
        val items = mutableListOf<FileItem>()

        publicDirs.forEach { dir ->
            val folder = File(baseDir, dir)
            if (folder.exists() && folder.isDirectory) {
                folder.listFiles()?.forEach { file ->
                    if (file.isFile) {
                        items.add(file.toItem())
                    }
                }
            }
        }

        items.groupBy { it.fileType }
            .mapValues { entry -> entry.value.sortedByDescending { it.lastModified } }
    }
}