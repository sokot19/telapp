package com.example.telegramfilemanager.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.telegramfilemanager.BuildConfig
import com.example.telegramfilemanager.model.FileItem
import com.example.telegramfilemanager.model.FileType

val chartColors = listOf(
    Color(0xFF3390EC), Color(0xFF8E44AD), Color(0xFF27AE60),
    Color(0xFFF39C12), Color(0xFFD35400), Color(0xFF2C3A48)
)

@Composable
fun ProfileScreen(fileData: Map<FileType, List<FileItem>>) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())
    ) {
        Text("آنالیز حافظه", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        StorageChart(fileData = fileData)
        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text("درباره ما", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))
        ProfileItem(icon = Icons.Outlined.Star, text = "امتیاز در مارکت", onClick = {
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.STORE_URL)))
            } catch (e: Exception) { /* Handle error */ }
        })
        Divider(modifier = Modifier.padding(vertical = 8.dp))

        Text("ارتباط با ما", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 16.dp))
        Spacer(Modifier.height(16.dp))
        ProfileItem(icon = Icons.Outlined.Send, text = "کانال تلگرام", onClick = {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/your_channel_id")))
        })
        ProfileItem(icon = Icons.Outlined.Person, text = "صفحه اینستاگرام", onClick = {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/your_username")))
        })
        ProfileItem(icon = Icons.Outlined.Email, text = "ایمیل پشتیبانی", onClick = {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", "support@example.com", null))
            intent.putExtra(Intent.EXTRA_SUBJECT, "پشتیبانی اپلیکیشن مدیر فایل تلگرام")
            context.startActivity(Intent.createChooser(intent, "ارسال ایمیل"))
        })
    }
}

@Composable
fun StorageChart(fileData: Map<FileType, List<FileItem>>) {
    val totalSize = remember(fileData) { fileData.values.flatten().sumOf { it.sizeBytes } }
    if (totalSize == 0L) {
        Box(modifier = Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
            Text("فایلی برای آنالیز یافت نشد.")
        }
        return
    }
    val sizePerCategory = remember(fileData) { fileData.mapValues { entry -> entry.value.sumOf { it.sizeBytes } }.entries.sortedByDescending { it.value } }

    Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
        Canvas(modifier = Modifier.size(120.dp)) {
            var startAngle = -90f
            sizePerCategory.forEachIndexed { index, entry ->
                val angle = (entry.value.toFloat() / totalSize.toFloat()) * 360f
                drawArc(color = chartColors[index % chartColors.size], startAngle = startAngle, sweepAngle = angle, useCenter = false, style = Stroke(width = 25f))
                startAngle += angle
            }
        }
        Spacer(Modifier.width(24.dp))
        Column(modifier = Modifier.fillMaxHeight(), verticalArrangement = Arrangement.Center) {
            sizePerCategory.forEachIndexed { index, entry ->
                ChartLegend(color = chartColors[index % chartColors.size], text = entry.key.displayName, size = entry.value)
            }
        }
    }
}

@Composable
fun ChartLegend(color: Color, text: String, size: Long) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        Box(modifier = Modifier.size(12.dp).background(color, shape = MaterialTheme.shapes.small))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.weight(1f))
        Text(formatBytes(size), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    ListItem(modifier = Modifier.clickable(onClick = onClick), headlineContent = { Text(text) }, leadingContent = { Icon(icon, contentDescription = text) })
}
