package com.example.telegramfilemanager.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.telegramfilemanager.model.FileItem
import com.example.telegramfilemanager.model.FileType
import kotlinx.coroutines.launch
import java.io.File
import java.text.StringCharacterIterator

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CategorizedFileListScreen(
    categorizedFiles: Map<FileType, List<FileItem>>,
    onRefresh: () -> Unit,
    onFileClick: (FileItem) -> Unit,
    onFileLongClick: (FileItem) -> Unit,
    selectedFiles: Set<FileItem>
) {
    val categories = remember(categorizedFiles) {
        categorizedFiles.keys.sortedBy { it.ordinal }
    }

    var showDeleteDialog by remember { mutableStateOf<FileItem?>(null) }
    var showDetailsDialog by remember { mutableStateOf<FileItem?>(null) }

    showDeleteDialog?.let { fileToDelete ->
        DeleteConfirmationDialog(
            fileItem = fileToDelete,
            onConfirm = {
                File(fileToDelete.path).delete()
                showDeleteDialog = null
                onRefresh()
            },
            onDismiss = { showDeleteDialog = null }
        )
    }

    showDetailsDialog?.let { fileDetails ->
        FileDetailsDialog(
            fileItem = fileDetails,
            onDismiss = { showDetailsDialog = null }
        )
    }

    if (categories.isEmpty()) {
        EmptyState("فایلی با این مشخصات یافت نشد.")
        return
    }

    val pagerState = rememberPagerState(pageCount = { categories.size })
    val coroutineScope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = pagerState.currentPage) {
            categories.forEachIndexed { index, category ->
                val totalSize = remember(categorizedFiles, category) {
                    categorizedFiles[category]?.sumOf { it.sizeBytes } ?: 0L
                }
                Tab(
                    selected = pagerState.currentPage == index,
                    onClick = { coroutineScope.launch { pagerState.animateScrollToPage(index) } },
                    text = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(category.displayName)
                            if (totalSize > 0) {
                                Text(
                                    formatBytes(totalSize),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                )
            }
        }

        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { pageIndex ->
            val category = categories[pageIndex]
            val filesForCategory = categorizedFiles[category] ?: emptyList()

            Crossfade(targetState = category, label = "Grid/List Toggle") { currentCategory ->
                if (currentCategory == FileType.IMAGE || currentCategory == FileType.VIDEO) {
                    FileGrid(
                        files = filesForCategory,
                        onFileClick = onFileClick,
                        onFileLongClick = onFileLongClick,
                        selectedFiles = selectedFiles,
                        onDeleteRequest = { showDeleteDialog = it },
                        onDetailsRequest = { showDetailsDialog = it }
                    )
                } else {
                    FileList(
                        files = filesForCategory,
                        onFileClick = onFileClick,
                        onFileLongClick = onFileLongClick,
                        selectedFiles = selectedFiles,
                        onDeleteRequest = { showDeleteDialog = it },
                        onDetailsRequest = { showDetailsDialog = it }
                    )
                }
            }
        }
    }
}

private fun shareFile(context: Context, fileItem: FileItem) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", File(fileItem.path))
    val intent = Intent(Intent.ACTION_SEND).apply {
        putExtra(Intent.EXTRA_STREAM, uri)
        type = context.contentResolver.getType(uri) ?: "*/*"
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری فایل"))
}

@Composable
private fun FileActionsDropdown(
    onDismiss: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    onDetails: () -> Unit
) {
    DropdownMenu(expanded = true, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text("اشتراک‌گذاری") }, onClick = onShare, leadingIcon = { Icon(Icons.Outlined.Share, null) })
        DropdownMenuItem(text = { Text("جزئیات") }, onClick = onDetails, leadingIcon = { Icon(Icons.Outlined.Info, null) })
        DropdownMenuItem(text = { Text("حذف") }, onClick = onDelete, leadingIcon = { Icon(Icons.Outlined.Delete, null) })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileList(
    files: List<FileItem>,
    onFileClick: (FileItem) -> Unit,
    onFileLongClick: (FileItem) -> Unit,
    selectedFiles: Set<FileItem>,
    onDeleteRequest: (FileItem) -> Unit,
    onDetailsRequest: (FileItem) -> Unit
) {
    val ctx = LocalContext.current
    val haptics = LocalHapticFeedback.current
    if (files.isEmpty()) {
        EmptyState("فایلی در این دسته پیدا نشد.")
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(files, key = { it.path }) { file ->
                var showMenu by remember { mutableStateOf(false) }
                FileRow(
                    item = file,
                    isSelected = selectedFiles.contains(file),
                    onClick = { onFileClick(file) },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        onFileLongClick(file)
                    },
                    onMoreClick = { showMenu = true }
                )
                if (showMenu) {
                    FileActionsDropdown(
                        onDismiss = { showMenu = false },
                        onShare = { shareFile(ctx, file); showMenu = false },
                        onDelete = { onDeleteRequest(file); showMenu = false },
                        onDetails = { onDetailsRequest(file); showMenu = false }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileGrid(
    files: List<FileItem>,
    onFileClick: (FileItem) -> Unit,
    onFileLongClick: (FileItem) -> Unit,
    selectedFiles: Set<FileItem>,
    onDeleteRequest: (FileItem) -> Unit,
    onDetailsRequest: (FileItem) -> Unit
) {
    val ctx = LocalContext.current
    val haptics = LocalHapticFeedback.current
    if (files.isEmpty()) {
        EmptyState("فایلی در این دسته پیدا نشد.")
    } else {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 128.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(files, key = { it.path }) { file ->
                var showMenu by remember { mutableStateOf(false) }
                FileGridItem(
                    item = file,
                    isSelected = selectedFiles.contains(file),
                    onClick = { onFileClick(file) },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        onFileLongClick(file)
                    },
                    onMoreClick = { showMenu = true }
                )
                if (showMenu) {
                    FileActionsDropdown(
                        onDismiss = { showMenu = false },
                        onShare = { shareFile(ctx, file); showMenu = false },
                        onDelete = { onDeleteRequest(file); showMenu = false },
                        onDetails = { onDetailsRequest(file); showMenu = false }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(
    item: FileItem,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onMoreClick: () -> Unit
) {
    val icon = when (item.fileType) {
        FileType.AUDIO -> Icons.Outlined.MusicNote
        FileType.DOCUMENT -> Icons.Outlined.Description
        FileType.VOICE -> Icons.Outlined.Mic
        else -> Icons.Outlined.FileOpen
    }
    ListItem(
        modifier = Modifier
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent),
        headlineContent = { Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text("${item.sizeHuman} • ${item.dateHuman}") },
        leadingContent = {
            Icon(imageVector = icon, contentDescription = item.fileType.displayName)
        },
        trailingContent = {
            IconButton(onClick = onMoreClick) {
                Icon(Icons.Default.MoreVert, contentDescription = "گزینه‌ها")
            }
        }
    )
    Divider(thickness = 0.5.dp)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileGridItem(
    item: FileItem,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onMoreClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .aspectRatio(1f)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = if (isSelected) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Box(contentAlignment = Alignment.BottomCenter) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(File(item.path))
                    .crossfade(true)
                    .build(),
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier.fillMaxWidth().fillMaxHeight(0.5f)
                    .background(Brush.verticalGradient(colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))))
            )
            if (isSelected) {
                Box(
                    modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = "Selected",
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }
            if (!isSelected) {
                Row(
                    modifier = Modifier.fillMaxWidth().align(Alignment.BottomStart).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onMoreClick) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = Color.White)
                    }
                }
            }
            if (item.fileType == FileType.VIDEO && !isSelected) {
                Icon(
                    Icons.Outlined.PlayCircle,
                    contentDescription = "Video",
                    tint = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.align(Alignment.Center).size(48.dp)
                )
            }
        }
    }
}

@Composable
private fun DeleteConfirmationDialog(fileItem: FileItem, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("حذف فایل") },
        text = { Text("آیا از حذف فایل «${fileItem.name}» مطمئن هستید؟ این عمل غیرقابل بازگشت است.") },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("حذف")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("لغو")
            }
        }
    )
}

@Composable
private fun FileDetailsDialog(fileItem: FileItem, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("جزئیات فایل") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("نام: ${fileItem.name}", style = MaterialTheme.typography.bodyMedium)
                Text("مسیر: ${fileItem.path}", style = MaterialTheme.typography.bodyMedium)
                Text("حجم: ${fileItem.sizeHuman} (${fileItem.sizeBytes} بایت)")
                Text("آخرین تغییر: ${fileItem.dateHuman}", style = MaterialTheme.typography.bodyMedium)
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("بستن")
            }
        }
    )
}

@Composable
private fun EmptyState(message: String) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Outlined.SentimentDissatisfied,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )
        Spacer(Modifier.height(16.dp))
        Text(message, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val characterIterator = StringCharacterIterator("kMGTPE")
    var tempBytes = bytes
    while (tempBytes >= 999_950) {
        tempBytes /= 1024
        characterIterator.next()
    }
    return String.format("%.1f %cB", tempBytes / 1024.0, characterIterator.current())
}