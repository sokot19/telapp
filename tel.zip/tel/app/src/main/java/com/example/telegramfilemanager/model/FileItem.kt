package com.example.telegramfilemanager.model

import java.io.File
import java.text.DateFormat
import java.util.*

data class FileItem(
    val path: String,
    val name: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val fileType: FileType
) {
    val sizeHuman: String
        get() {
            val kb = 1024.0
            val mb = kb * 1024
            val gb = mb * 1024
            return when {
                sizeBytes >= gb -> String.format("%.2f GB", sizeBytes / gb)
                sizeBytes >= mb -> String.format("%.2f MB", sizeBytes / mb)
                sizeBytes >= kb -> String.format("%.2f KB", sizeBytes / kb)
                else -> "$sizeBytes B"
            }
        }

    val dateHuman: String
        get() = DateFormat.getDateTimeInstance().format(Date(lastModified))
}

fun File.toItem(): FileItem {
    val type = when (extension.lowercase()) {
        "mp4", "mkv", "mov", "webm" -> FileType.VIDEO
        "jpg", "jpeg", "png", "gif", "webp", "bmp" -> FileType.IMAGE
        "mp3", "wav", "m4a", "flac" -> FileType.AUDIO
        "ogg" -> FileType.VOICE // تشخیص پیام صوتی
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "zip", "rar" -> FileType.DOCUMENT
        else -> FileType.OTHER
    }

    return FileItem(
        path = absolutePath,
        name = name,
        sizeBytes = length(),
        lastModified = lastModified(),
        fileType = type
    )
}