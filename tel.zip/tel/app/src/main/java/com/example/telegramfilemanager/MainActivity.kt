package com.example.telegramfilemanager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.telegramfilemanager.model.FileItem
import com.example.telegramfilemanager.model.FileType
import com.example.telegramfilemanager.ui.CategorizedFileListScreen
import com.example.telegramfilemanager.ui.FileViewer
import com.example.telegramfilemanager.ui.ProfileScreen
import com.example.telegramfilemanager.ui.theme.TelegramFileManagerTheme
import com.example.telegramfilemanager.util.TelegramScanner
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

// مدل برای صفحات و گزینه‌های مرتب‌سازی
sealed class Screen(val route: String) {
    object Files : Screen("files")
    object Profile : Screen("profile")
}

enum class SortOption {
    ByDateDescending, ByDateAscending, ByNameAscending, ByNameDescending, BySizeDescending, BySizeAscending
}

class MainViewModel : ViewModel() {
    private val _isInitialLoading = MutableStateFlow(true)
    val isInitialLoading = _isInitialLoading.asStateFlow()

    init {
        viewModelScope.launch {
            delay(2500) // تاخیر شبیه‌سازی شده برای نمایش بهتر اسپلش
            _isInitialLoading.value = false
        }
    }
}

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { recreate() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installSplashScreen().apply {
            setKeepOnScreenCondition {
                viewModel.isInitialLoading.value
            }
        }
        setContent {
            TelegramFileManagerTheme {
                MainScreen(onRequestPermissions = {
                    permissionLauncher.launch(requiredPermissions)
                })
            }
        }
    }

    companion object {
        val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }
}

@Composable
fun MainScreen(onRequestPermissions: () -> Unit) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Files) }
    var fileToView by remember { mutableStateOf<FileItem?>(null) }
    var categorizedFiles by remember { mutableStateOf(emptyMap<FileType, List<FileItem>>()) }

    fileToView?.let { FileViewer(fileItem = it, onDismiss = { fileToView = null }) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = currentScreen is Screen.Files, onClick = { currentScreen = Screen.Files }, icon = { Icon(Icons.Outlined.Folder, "فایل‌ها") }, label = { Text("فایل‌ها") })
                NavigationBarItem(selected = currentScreen is Screen.Profile, onClick = { currentScreen = Screen.Profile }, icon = { Icon(Icons.Outlined.Person, "پروفایل") }, label = { Text("پروفایل") })
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (currentScreen) {
                is Screen.Files -> FilesTabContent(
                    onRequestPermissions = onRequestPermissions,
                    onFileClick = { fileToView = it },
                    categorizedFiles = categorizedFiles,
                    onCategorizedFilesChange = { categorizedFiles = it }
                )
                is Screen.Profile -> ProfileScreen(fileData = categorizedFiles)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesTabContent(
    onRequestPermissions: () -> Unit,
    onFileClick: (FileItem) -> Unit,
    categorizedFiles: Map<FileType, List<FileItem>>,
    onCategorizedFilesChange: (Map<FileType, List<FileItem>>) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val hasPermissions by remember { mutableStateOf(MainActivity.requiredPermissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }) }

    var isLoading by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var sortOption by remember { mutableStateOf(SortOption.ByDateDescending) }
    var isSelectionMode by remember { mutableStateOf(false) }
    var selectedFiles by remember { mutableStateOf(emptySet<FileItem>()) }
    var showMultiDeleteDialog by remember { mutableStateOf(false) }

    if (showMultiDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showMultiDeleteDialog = false },
            title = { Text("حذف فایل‌ها") },
            text = { Text("آیا از حذف ${selectedFiles.size} مورد انتخاب شده مطمئن هستید؟") },
            confirmButton = { Button(onClick = {
                selectedFiles.forEach { File(it.path).delete() }
                val remainingFiles = categorizedFiles.mapValues { entry -> entry.value.filterNot { selectedFiles.contains(it) } }
                onCategorizedFilesChange(remainingFiles)
                selectedFiles = emptySet()
                isSelectionMode = false
                showMultiDeleteDialog = false
            }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("حذف کن") } },
            dismissButton = { OutlinedButton(onClick = { showMultiDeleteDialog = false }) { Text("لغو") } }
        )
    }

    val filesToDisplay = remember(searchQuery, categorizedFiles, sortOption) {
        val filtered = if (searchQuery.isBlank()) categorizedFiles else categorizedFiles.mapValues { (_, files) -> files.filter { it.name.contains(searchQuery, ignoreCase = true) } }.filterValues { it.isNotEmpty() }
        filtered.mapValues { (_, files) ->
            when (sortOption) {
                SortOption.ByDateDescending -> files.sortedByDescending { it.lastModified }
                SortOption.ByDateAscending -> files.sortedBy { it.lastModified }
                SortOption.ByNameAscending -> files.sortedBy { it.name }
                SortOption.ByNameDescending -> files.sortedByDescending { it.name }
                SortOption.BySizeDescending -> files.sortedByDescending { it.sizeBytes }
                SortOption.BySizeAscending -> files.sortedBy { it.sizeBytes }
            }
        }
    }

    val refreshData: () -> Unit = { scope.launch { isLoading = true; onCategorizedFilesChange(TelegramScanner.scanPublicFolders()); isLoading = false } }
    LaunchedEffect(hasPermissions) { if (hasPermissions) refreshData() }

    Scaffold(topBar = {
        Crossfade(targetState = isSelectionMode, label = "TopBar") { inSelectionMode ->
            if (inSelectionMode) {
                SelectionTopAppBar(
                    selectionCount = selectedFiles.size,
                    onClearSelection = { selectedFiles = emptySet(); isSelectionMode = false },
                    onDeleteSelected = { showMultiDeleteDialog = true },
                    onShareSelected = {
                        val uris = selectedFiles.map { FileProvider.getUriForFile(context, "${context.packageName}.provider", File(it.path)) }
                        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply { type = "*/*"; putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                        context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری فایل‌ها"))
                        selectedFiles = emptySet()
                        isSelectionMode = false
                    }
                )
            } else { DefaultTopAppBar(onSortChange = { sortOption = it }, onRefresh = refreshData, hasPermissions = hasPermissions) }
        }
    }) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues)) {
            if (hasPermissions) {
                OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), label = { Text("جستجو...") }, leadingIcon = { Icon(Icons.Default.Search, "جستجو") }, singleLine = true)
                if (isLoading) LoadingScreen() else CategorizedFileListScreen(categorizedFiles = filesToDisplay, onRefresh = refreshData, onFileClick = { file -> if (isSelectionMode) selectedFiles = if (selectedFiles.contains(file)) selectedFiles - file else selectedFiles + file else onFileClick(file) }, onFileLongClick = { file -> isSelectionMode = true; selectedFiles = selectedFiles + file }, selectedFiles = selectedFiles)
            } else { PermissionRequestScreen(onRequestPermissions) }
        }
    }
}

@Composable
private fun PermissionRequestScreen(onGrantClick: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("برای نمایش فایل‌های تلگرام، لطفاً دسترسی به رسانه‌ها را بدهید.", style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onGrantClick) { Text("اعطای دسترسی") }
    }
}

@Composable
private fun LoadingScreen() { Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DefaultTopAppBar(onSortChange: (SortOption) -> Unit, onRefresh: () -> Unit, hasPermissions: Boolean) {
    var showSortMenu by remember { mutableStateOf(false) }
    TopAppBar(title = { Text("مدیر فایل تلگرام") }, actions = {
        if (hasPermissions) {
            IconButton(onClick = { showSortMenu = true }) { Icon(Icons.Outlined.Sort, "مرتب‌سازی") }
            DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                DropdownMenuItem(text = { Text("جدیدترین") }, onClick = { onSortChange(SortOption.ByDateDescending); showSortMenu = false })
                DropdownMenuItem(text = { Text("قدیمی‌ترین") }, onClick = { onSortChange(SortOption.ByDateAscending); showSortMenu = false })
                DropdownMenuItem(text = { Text("نام (صعودی)") }, onClick = { onSortChange(SortOption.ByNameAscending); showSortMenu = false })
                DropdownMenuItem(text = { Text("نام (نزولی)") }, onClick = { onSortChange(SortOption.ByNameDescending); showSortMenu = false })
                DropdownMenuItem(text = { Text("حجم (بیشترین)") }, onClick = { onSortChange(SortOption.BySizeDescending); showSortMenu = false })
                DropdownMenuItem(text = { Text("حجم (کمترین)") }, onClick = { onSortChange(SortOption.BySizeAscending); showSortMenu = false })
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "اسکن دوباره") }
        }
    })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectionTopAppBar(selectionCount: Int, onClearSelection: () -> Unit, onDeleteSelected: () -> Unit, onShareSelected: () -> Unit) {
    TopAppBar(
        title = { Text("$selectionCount مورد انتخاب شده") },
        navigationIcon = { IconButton(onClick = onClearSelection) { Icon(Icons.Default.Close, "لغو انتخاب") } },
        actions = {
            IconButton(onClick = onDeleteSelected) { Icon(Icons.Default.Delete, "حذف") }
            IconButton(onClick = onShareSelected) { Icon(Icons.Default.Share, "اشتراک‌گذاری") }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    )
}
