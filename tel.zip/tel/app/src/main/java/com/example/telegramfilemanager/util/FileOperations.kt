package com.example.telegramfilemanager.util

import com.example.telegramfilemanager.model.FileItem
import java.io.File

object FileOperations {
    fun deleteLargeFiles(files: List<FileItem>, sizeThresholdBytes: Long) {
        files.forEach {
            if (it.sizeBytes > sizeThresholdBytes) {
                File(it.path).delete()
            }
        }
    }
}
