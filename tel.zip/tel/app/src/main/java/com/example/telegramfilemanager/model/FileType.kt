package com.example.telegramfilemanager.model

enum class FileType(val displayName: String) {
    VIDEO("ویدیوها"),
    IMAGE("تصاویر"),
    AUDIO("موسیقی‌ها"),
    VOICE("پیام‌های صوتی"), // دسته جدید
    DOCUMENT("اسناد"),
    OTHER("سایر فایل‌ها")
}