package com.example.telegramfilemanager.util

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri

object UriPreferences {
    private const val PREFS_NAME = "telegram_folder_prefs"
    private const val KEY_FOLDER_URI = "folder_uri"

    private fun getPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun saveUri(context: Context, uri: Uri) {
        getPreferences(context).edit().putString(KEY_FOLDER_URI, uri.toString()).apply()
    }

    fun loadUri(context: Context): Uri? {
        val uriString = getPreferences(context).getString(KEY_FOLDER_URI, null)
        return uriString?.let { Uri.parse(it) }
    }

    fun clearUri(context: Context) {
        getPreferences(context).edit().remove(KEY_FOLDER_URI).apply()
    }
}