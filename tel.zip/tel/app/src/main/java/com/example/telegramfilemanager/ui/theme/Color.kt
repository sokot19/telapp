package com.example.telegramfilemanager.ui.theme

import androidx.compose.ui.graphics.Color

val TelegramBlue = Color(0xFF3390EC)
val White = Color(0xFFFFFFFF)
val LightBackground = Color(0xFFF0F4F7)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF1D1D1F)
val LightGray = Color(0xFFE5E5EA)

val DarkBackground = Color(0xFF18222D)
val DarkSurface = Color(0xFF212D3B)
val DarkOnSurface = Color(0xFFFFFFFF)
val DarkGray = Color(0xFF2C3A48)